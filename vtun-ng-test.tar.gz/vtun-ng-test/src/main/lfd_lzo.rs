/*
    VTun-ng - Forked from VTun in 2025
    VTun - Virtual Tunnel over TCP/IP network.

    Copyright (C) 1998-2016  Maxim Krasnyansky <max_mk@yahoo.com>
    Copyright (C) 2025 Jan-Espen Oversand <sigsegv@radiotube.org>

    VTun has been derived from VPPP package by Maxim Krasnyansky.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 */

/* LZO compression module */

#[cfg(feature = "lzo")]
use rust_lzo::{worst_compress, LZOContext, LZOError};
use crate::{lfd_mod, linkfd, vtun_host};
use crate::linkfd::LfdMod;
use crate::mainvtun::VtunContext;
use crate::syslog::SyslogObject;

#[cfg(feature = "lzo")]
struct LfdLzo {
    pub compress_ctx: LZOContext,
}

#[cfg(feature = "lzo")]
impl LfdLzo {
    pub fn new(ctx: &VtunContext, _host: &vtun_host::VtunHost) -> LfdLzo {
        ctx.syslog(lfd_mod::LOG_INFO, "LZO compression initialized");
        LfdLzo {
            compress_ctx: LZOContext::new()
        }
    }
}

pub(crate) struct LfdLzoFactory {
}

impl LfdLzoFactory {
    pub fn new() -> LfdLzoFactory {
        LfdLzoFactory {
        }
    }
}

#[cfg(feature = "lzo")]
impl linkfd::LfdModFactory for LfdLzoFactory {
    fn create(&self, ctx: &VtunContext, host: &mut vtun_host::VtunHost) -> Result<Box<dyn LfdMod>,i32> {
        Ok(Box::new(LfdLzo::new(ctx, host)))
    }
}

#[cfg(not(feature = "lzo"))]
impl linkfd::LfdModFactory for LfdLzoFactory {
    fn create(&self, ctx: &VtunContext, _host: &mut vtun_host::VtunHost) -> Result<Box<dyn LfdMod>,i32> {
        ctx.syslog(lfd_mod::LOG_ERR, "LZO compression is not supported, rebuild with lzo enabled");
        Err(2)
    }
}

#[cfg(feature = "lzo")]
impl LfdMod for LfdLzo {
    fn encode(&mut self, ctx: &VtunContext, buf: &mut Vec<u8>) -> Result<(),()> {
        let mut compressed: Vec<u8> = Vec::new();
        compressed.reserve(worst_compress(buf.len()));
        let err = self.compress_ctx.compress(buf, &mut compressed);
        if err == LZOError::OK {
            buf.resize(compressed.len(), 0u8);
            for i in 0..compressed.len() {
                buf[i] = compressed[i];
            }
            Ok(())
        } else {
            ctx.syslog(lfd_mod::LOG_ERR, "LZO compression failed");
            Err(())
        }
    }
    fn decode(&mut self, ctx: &VtunContext, buf: &mut Vec<u8>) -> Result<(),()> {
        let mut decompressed: Vec<u8> = Vec::new();
        decompressed.resize(buf.len() * 4, 0u8);
        let (result, err) = LZOContext::decompress_to_slice(&buf, &mut decompressed);
        if err == LZOError::OK {
            buf.resize(result.len(), 0u8);
            for i in 0..result.len() {
                buf[i] = result[i];
            }
            Ok(())
        } else {
            ctx.syslog(lfd_mod::LOG_ERR, "LZO decompression failed");
            Err(())
        }
    }

    fn request_send(&mut self) -> bool {
        false
    }
}
