#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <unistd.h>
#include <syslog.h>

#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <resolv.h>
#include <netdb.h>

/* Default 512 Kbytes */
long amount = 512 * 1024;
int port = 10000;

float tv2fl(struct timeval tv)
{
     return (float)tv.tv_sec + (float)(tv.tv_usec/1000000.0); 
}

void read_mode(void)
{	  
     struct timeval tv_beg,tv_end,tv_diff;
     struct sockaddr_in my_addr,cln_addr;
     int  s,s1,opt,r;
     char buf[1024];
     long total;
   
     memset(&my_addr,0,sizeof(my_addr));
     my_addr.sin_family = AF_INET;
     my_addr.sin_addr.s_addr = INADDR_ANY;
     my_addr.sin_port = htons(port);	

     memset(&cln_addr,0,sizeof(cln_addr));
     cln_addr.sin_family = AF_INET;
     cln_addr.sin_addr.s_addr = 0;
     cln_addr.sin_port = 0;	

     if( (s=socket(AF_INET,SOCK_STREAM,0))==-1 ){
	syslog(LOG_ERR,"Can not create socket");
	exit(1);
     }

     if( bind(s,(struct sockaddr *)&my_addr,sizeof(my_addr)) ){
	syslog(LOG_ERR,"Can not bind to the socket");
	exit(1);
     }

     if( listen(s,5) ){
	syslog(LOG_ERR,"Can not listen on the socket");
	exit(1);
     }

     syslog(LOG_INFO,"Waiting for data");

     opt=sizeof(cln_addr);
     if( (s1=accept(s,&cln_addr,&opt)) < 0 ){
	syslog(LOG_ERR,"Accept error");
	exit(1); 
     }

     syslog(LOG_INFO,"Coping...");
  
     while(1){
        gettimeofday(&tv_beg,NULL);
        total = 0;
        while(total < amount) {	
           if( (r=recv(s1,buf,sizeof(buf),0)) <= 0)
	      exit(1);
           total+=r; 
        }
        gettimeofday(&tv_end,NULL);

        timersub(&tv_end,&tv_beg,&tv_diff);

        syslog(LOG_INFO,"%ld bytes in %.2fm speed %.2f kb",total,
			tv2fl(tv_diff) / 60.0,
			(float)( total / tv2fl(tv_diff) ) / 1024.0 );	
     }

     close(s);close(s1);
}	


void write_mode(char *svr)
{
     struct sockaddr_in my_addr,svr_addr;
     struct hostent *hent;
     char   buf[1024];
     int    s,i;

     if( !(hent=gethostbyname(svr)) ){
	syslog(LOG_ERR,"Can't resolve server address"); 
	exit(1);
     }
	
     memset(&my_addr,0,sizeof(my_addr));
     my_addr.sin_family = AF_INET;
     my_addr.sin_addr.s_addr = INADDR_ANY;
     my_addr.sin_port = 0;	

     memset(&svr_addr,0,sizeof(svr_addr));
     svr_addr.sin_family = AF_INET;
     svr_addr.sin_addr.s_addr = *((unsigned long *)hent->h_addr);
     svr_addr.sin_port = htons(port);	

     if( (s=socket(AF_INET,SOCK_STREAM,0))==-1 ){
	syslog(LOG_ERR,"Can not create socket");
	exit(1);
     }

     if( bind(s,(struct sockaddr *)&my_addr,sizeof(my_addr)) ){
	syslog(LOG_ERR,"Can not bind to the socket");
	exit(1);
     }

     for(i=0; i < 1024; i++)
        buf[i]=(i%40)+'A';

     if( connect(s,(struct sockaddr *)&svr_addr,sizeof(svr_addr)) ){
	syslog(LOG_ERR,"Can not connect to the server");
	exit(1);
     }    

     syslog(LOG_INFO,"Writing");

     while(1)
 	if( send(s,buf,1024,0) <= 0 ) {
	   syslog(LOG_ERR,"Write error");
	   exit(1);
	}
}	


void usage(void)
{
     fprintf(stderr,"tcpspeed <-w write or -r read> [-b kbytes] [-p port] [server_addr]\n");
}

extern int optind,opterr,optopt;
extern char *optarg;

int main(int argc ,char *argv[])
{
     int opt,wr = 0;

     while( (opt=getopt(argc,argv,"p:wrb:")) != EOF ){
	switch(opt){
	    case 'p':
		port= atoi(optarg);
		break;
	    case 'b':
		amount = atoi(optarg) * 1024;
		break;
	    case 'w':
		wr = 1;
		break;
	    case 'r':
		wr = 0;
		break;
	    default:
		usage();
	        exit(1);
	}
     }	

     if( !(argc - optind) && wr ){
	usage();
	exit(1);
     }
     
     openlog("tcpspeed",LOG_PERROR | LOG_PID, LOG_LOCAL0);
    
     if( wr )
 	write_mode(argv[optind]);
     else
	read_mode();

     closelog();

     return 0;
}
