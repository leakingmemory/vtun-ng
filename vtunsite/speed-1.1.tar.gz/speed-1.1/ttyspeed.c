#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <unistd.h>
#include <syslog.h>

/* Default 512 Kbytes */
long amount = 512 * 1024;

int fd;

float tv2fl(struct timeval tv)
{
     return (float)tv.tv_sec + (float)(tv.tv_usec/1000000.0); 
}

void read_mode(void)
{	  
     struct timeval tv_beg,tv_end,tv_diff;
     char buf[1024];
     long total;
     fd_set fds;     
     int r;

     FD_ZERO(&fds);
     FD_SET(fd,&fds);
	
     syslog(LOG_INFO,"Waiting for data");

     if( select(fd+1,&fds,NULL,NULL,NULL) < 0 ){
	printf("select error \n");
	exit(1); 
     }
     syslog(LOG_INFO,"Reading ...");       

     while(1){
	gettimeofday(&tv_beg,NULL);

	total = 0;
	while(total < amount) {	
	   if( (r=read(fd,buf,1024)) <= 0)
	      exit(1);
           total+=r; 
        }

        gettimeofday(&tv_end,NULL);

        timersub(&tv_end,&tv_beg,&tv_diff);

        syslog(LOG_INFO,"%ld bytes in %.2fm speed %.2f kb",total,
			tv2fl(tv_diff) / 60.0,
			(float)( total / tv2fl(tv_diff) ) / 1024.0 );	
     }
}

void write_mode(void)
{
     int i;
     char buf[1024];

     for(i=0; i < 1024; i++)
        buf[i]=(i%20)+'A';

     syslog(LOG_INFO,"Writing ...");       

     while(1){   
        while(1)
 	   if( write(fd,buf,1024) < 0 ) {
	      syslog(LOG_ERR,"Write error");
	      exit(1);
	   }
     }
}

void usage(void)
{
     fprintf(stderr,"ttyspeed <-w write or -r read> [-b kbytes] [port]\n");
}

extern int optind,opterr,optopt;
extern char *optarg;

int main(int argc ,char *argv[])
{
     int opt,wr = 0;

     while( (opt=getopt(argc,argv,"wrb:")) != EOF ){
	switch(opt){
	    case 'b':
		amount = atoi(optarg) * 1024;
		break;
	    case 'w':
		wr = 1;
		break;
	    case 'r':
		wr = 0;
		break;
	    default:
		usage();
	        exit(1);
	}
     }	

     if( (argc - optind) )
        fd=open(argv[optind],O_RDWR);
     else 
	if(wr)
           fd=1;
        else
	   fd=0;
     
     openlog("ttyspeed",LOG_PERROR | LOG_PID, LOG_LOCAL0);
    
     if( wr )
 	write_mode();
     else
	read_mode();

     close(fd);
     closelog();

     return 0;
}
